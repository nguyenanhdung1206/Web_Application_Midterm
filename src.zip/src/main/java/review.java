/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author lenovo
 */
@WebServlet(urlPatterns = {"/review"})
public class review extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet review</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet review at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            
            //Review contents//
            HttpSession session = request.getSession(true);
            String movie = (String)request.getParameter("movie");
            switch(movie){
                case "Avengers: Endgame":
                    session.setAttribute("poster","movie1");
                    session.setAttribute("rating","9.8/10");
                    session.setAttribute("content","It all comes to an end in the epic superhero film Avengers: Endgame. In the wake of Thanos' mass genocide the Avengers come up with a plan to get everyone back. Once again the writers have done an extraordinary job at integrating and interweaving the various Marvel properties. And the special effects are just amazing; especially during the final battle sequence, capturing the massive scope of the battle and the multiple fights going on between the characters. Each superhero gets their moment to shine, and a number of greatest hits moments from the MCU are revisited, Back to the Future Part II style. Still, there are some pacing issues and more than a few plot contrivances. Yet despite whatever problems it has, Avengers: Endgames is an incredible achievement.");
                    break;
                case "American Psycho":
                    session.setAttribute("poster","movie2");
                    session.setAttribute("rating","8.5/10");
                    session.setAttribute("content","A surprisingly influential film. American Psycho gives us a dark, funny and amazing performance by Christian Bale, smart writing, plot and great performances all around. American Psycho is a dark comedy keep in mind.... don't go into it expecting it to be full comedy, there will be some scenes that will disturb you and haunt you for life and it is glorious! One of my favourites, spread the love of this film all around, tell your friends, family (probably not a good idea...) and loved ones they'll get a kick out of this flick. Two thumbs up!");
                    break;
                case "Avengers: Infinity War":
                    session.setAttribute("poster","movie3");
                    session.setAttribute("rating","9.5/10");
                    session.setAttribute("content","The Marvel Universe unites in Avengers: Infinity War, an epic, action-packed adventure. When the Mad Titan Thanos comes to Earth to collect the last Infinity Stone the Avengers assemble and wage a desperate battle to save the universe from Thanos' plans for mass genocide. The film does an extraordinary job at bringing together all of the different Marvel characters and teams them up in interesting ways. And the chases and fight scenes are incredibly exciting and well-choreographed. The special effects and the CGI are also really good (with the exception of the disintegration effects). However, the plot is weak and ends rather abruptly. Additionally, Thanos proves to be a fairly generic villain and a little too all-powerful. Yet despite a few weaknesses, Avengers: Infinity War is an unparalleled cinematic event (the culmination of ten years of filmmaking) that has a remarkably ambitious vision.");
                    break;
                case "Parasite":
                    session.setAttribute("poster","movie4");
                    session.setAttribute("rating","10/10");
                    session.setAttribute("content","Writer/director Bong Joon Ho (\"The Host\" \"Snowpiercer\" \"Okja\") has been on a roll of late with thought provoking genre films with underlying social commentary. From river monsters, to end-of-the-world tales, to a pig-like Totoro, Bong is not afraid to take seemingly popcorn concepts and work them into a smart film that has arthouse and movieplex crossover appeal. With \"Parasite\" he takes a more subtle route and tells the story of a struggling family living in a tiny basement hovel in South Korea where they have to leech off neighbors unprotected wifi and deal with nightly public urination outside their alley-side windows. When the son lands a job as a tutor for the daughter of a rich family by pretending to be a college student and lying about his resume, he spots an opportunity to recommend his sister as an art teacher for the younger brother, hiding that she's his sister and lying about her credentials as well. Next the brother and sister scheme to get the chauffeur fired so their dad can land the job and then how to fire the longtime housekeeper so their mom can snatch that opening. To tell more would spoil the fun, but I will say the film takes an unexpected turn and dramatic shift in tone. I had no idea where the film was going or how it was going to end and the ultimate ending is quite a shocker. What's most interesting about the film is asking the question, who really is the parasite? Is it the lower class family living off the rich family host or is it this privileged rich family living off the backs of their working class servants? The answer is that it could be either or most likely both. Bong's thesis appears to be that this situation of haves and have-nots coexisting is untenable and will lead to an inevitable collision course, much as it happened in his prior film \"Snowpiercer.\" Bong sums it up best himself when he was described \"Parasite\" as \"a comedy without clowns, a tragedy without villains.\" If I had a complaint about the film it's that the shift from humorous satire to something darker felt a bit incongruous, but Bong likely did this intentionally to bolster the film's message around the inevitable conclusion of a world of stark haves and have-nots. \"Parasite\" is a compelling film that delivers a pure cinematic experience, meaning that it's a story that could not have been told in any other medium, and is an absolute treat for cinema lovers.");
                    break;
                case "Joker":
                    session.setAttribute("poster","movie5");
                    session.setAttribute("rating","10/10");
                    session.setAttribute("content","A movie I've had to sit on for several days and I think I'll have to sit on even longer. Controversial, dangerous, these are words thrown around a lot with this movie. I guess I see why, but maybe not for the right reason. It's asking questions, but a lot of people are getting the wrong thing out of those questions. Are they questions that have been asked before? Have they been asked in a similar way? Sure, but maybe not in this climate and certainly not with this character, and that's what makes it different. Without going too deep into my own theories, the biggest thing I got out of it is \"help people\". There were so many points where this slow-motion car crash could have been stopped, but it didn't. Another thing is, how much are other people to blame? These are interesting questions, and what makes it more interesting is knowing this character and where he ends up. As to the violence, none of the violence is particularly over the top in a Deadpool or Michael Bay sort of way, but that's sort of what makes it more uncomfortable. It's grounded and unnerving. It's also very Joker-ish, with some scenes that are weirdly playful in a bizarre way where you don't really know what he's going to do. This was a unique direction to take this character, and Joaquin Phoenix kills it as Arthur/Joker with a empathic psychopath. It's a thoughtful but uncomfortable feel-bad sort of movie I'm still thinking about and really want to talk about. I don't get that sort of movie often enough.");
                    break;
                case "Aquaman":
                    session.setAttribute("poster","movie6");
                    session.setAttribute("rating","8.5/10");
                    session.setAttribute("content","DC makes a hard turn toward the fantastical with James Wan's Aquaman. When King Orm attempts to unite the kingdoms of Atlantis to attack the surface world Princess Mera seeks out the help of Arthur Curry, the king's half-brother, to stop Orm's coming war. Starring Jason Momoa, Amber Heard, Patrick Wilson, Willem Dafoe, Dolph Lundgren, and Nicole Kidman, the film has an impressive cast. And, the special effects are pretty good; featuring a lot of interesting set and creature designs, creating a fascinating new world within the DC Universe. However, the plot is formulaic and the Atlantis mythology is rather bizarre. Still, despite some problems, Aquaman is an incredibly fun and entertaining action film.");
                    break;
                case "Inception":
                    session.setAttribute("poster","movie7");
                    session.setAttribute("rating","9/10");
                    session.setAttribute("content","A truly sensational film. I hadn't rewatched this for years and almost forgot how outstanding it is. First of all, what a cast 'Inception' has. Leonardo DiCaprio, Joseph Gordon-Levitt, Tom Hardy, Cillian Murphy, Ellen Page, Ken Watanabe, Marion Cotillard and (albeit minor) Michael Caine. Tremendous performances from all of them. DiCaprio is always a great watch, he kills it in this production - the perfect person to play Cobb. Gordon-Levitt and Page are excellent here, despite being the two I'd (wrongly) assume would be the weaker performers. Hardy and Murphy are the opposite, I expected top level and they certainly gave it. Everything about this is astoundingly good. Christopher Nolan & Co. get it so, so right. The film is such a smooth ride in terms of following the premise, in spite of the roller coaster ride you experience seeing it play out. The ending is fantastic too, many films on this scale mess up the conclusion but they don't. If all that isn't enough, they even got Hans Zimmer to score the damn thing. Icing on the cake.");
                    break;
                case "Us":
                    session.setAttribute("poster","movie8");
                    session.setAttribute("rating","9.3/10");
                    session.setAttribute("content","Jordan Peele follows up his breakout hit, Get Out, with the psychological horror-thriller Us. While on vacation a family is attacked by what appear to be their doppelgangers. The script is a little weak and opens up a lot more questions than it can answer. However, the performances are pretty decent (some are downright terrifying). And though the \"privilege\" allegory is a little muddled, Peele does a good job at building suspense and tension. Additionally, the violence is pretty intense without being gratuitous or exploitative. While there are parts of Us that don't work, overall it's a chilling horror film.");
                    break;
                case "Get out":
                    session.setAttribute("poster","movie9");
                    session.setAttribute("rating","9.5/10");
                    session.setAttribute("content","The less you know about this movie before you watch it, the better. It's a creepy, delicious thriller, and one where even when you think you know what might be going on, there's more to it than you realize. There are elements that feel derivative, but on the other hand, Director Jordan Peele tells this story well, and it feels fresh and intelligent. Daniel Kaluuya and Allison Williams turn in very nice performances, and the supporting cast is solid as well. I loved Lil Rel Howery, who plays the friend, a TSA agent who tries to help from afar. There are many great moments - the round of \"Bingo\" led by the father, Kaluuya seeing the pictures of Williams and her expression on that last one, and the effects going to the \"sunken place\". It also puts a mirror up to how white people in real life, even well-meaning ones, sometimes talk to African-Americans in their attempts to relate to them or 'be cool' - stilted, with references that often bring up race, and at least sometimes subtly racist. How great it was to see a diverse cast, and to see this perspective, without it being delivered in a heavy-handed manner. It's not original enough to be in a list of greatest ever thrillers, but it's solid and enjoyable from beginning to end.");
                    break;
                case "Spider-Man: Into the Spider-Verse":
                    session.setAttribute("poster","movie10");
                    session.setAttribute("rating","10/10");
                    session.setAttribute("content","Fully embraces its comic origins and the realization that most viewers know the ins and outs of Spideys story. Where it goes from there is exciting, both visually and plot-wise. The animation is gorgeous and as diverse as the fantastic voice cast. Ultimately, after some very sweet and emotional scenes, the showdown does get a little messy in its wild chaos of colors, shapes and maelstroms, the entire film is certainly not for epileptics. It's also unfortunate that the songs are pretty dreadful when you are older than 13. That being said, the film is still a pleasure and brings some fresh air to the table.");
                    break;
                default:
                    session.setAttribute("poster","none");
                    session.setAttribute("content","none");
                    session.setAttribute("rating","none");
            }
            response.sendRedirect("reviews.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
